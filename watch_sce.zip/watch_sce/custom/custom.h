/*
* Copyright 2026 NXP
* NXP Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#ifndef CUSTOM_H
#define CUSTOM_H
#ifdef __cplusplus
extern "C" {
#endif

#include "../generated/gui_guider.h"

void custom_init(gg_ui_t *ui);

#ifdef __cplusplus
}
#endif
#endif /* CUSTOM_H */
