#include "Key.h"

static uint8_t stable_down;

uint8_t key_is_pressed(void)
{
    return stable_down;
}

key_event_t key_scan(GPIO_TypeDef *port, uint16_t pin)
{
    static uint8_t sampled_down, long_sent;
    static uint32_t changed_at, pressed_at;
    uint32_t now = HAL_GetTick();
    uint8_t down = HAL_GPIO_ReadPin(port, pin) == GPIO_PIN_RESET;

    if (down != sampled_down) {
        sampled_down = down;
        changed_at = now;
    }
    if (stable_down != sampled_down && now - changed_at >= KEY_DEBOUNCE_MS) {
        stable_down = sampled_down;
        if (!stable_down) {
            if (long_sent) return KEY_EVT_NONE;
            return changed_at - pressed_at >= KEY_LONG_MS ? KEY_EVT_LONG : KEY_EVT_SHORT;
        }
        pressed_at = changed_at;
        long_sent = 0;
    }
    if (stable_down && down && !long_sent && now - pressed_at >= KEY_LONG_MS) {
        long_sent = 1;
        return KEY_EVT_LONG;
    }
    return KEY_EVT_NONE;
}
