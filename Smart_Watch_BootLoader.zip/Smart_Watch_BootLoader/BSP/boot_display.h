#ifndef BOOT_DISPLAY_H
#define BOOT_DISPLAY_H

void display_init(void);
void display_message(const char *title, const char *detail, const char *action);
void display_progress(unsigned percent);
void display_off(void);

#endif
