#include "boot_display.h"
#include "lcd.h"
#include "lcd_init.h"
#include "spi.h"
#include "tim.h"
#include <string.h>

#define TEXT_HEIGHT 24U
#define AQUA 0x5EFAU

static void line(unsigned y, const char *text, uint16_t color)
{
    unsigned width = strlen(text) * (TEXT_HEIGHT / 2U);
    if (width > LCD_W) return;
    LCD_ShowString((LCD_W - width) / 2U, y, (const u8 *)text, color, BLACK, TEXT_HEIGHT, 0);
}

void display_init(void)
{
    LCD_Init();
    LCD_Fill(0, 0, LCD_W, LCD_H, BLACK);
    line(26, "Watch bootloader", WHITE);
    LCD_Fill(20, 60, LCD_W - 20, 62, GRAY);
    LCD_Set_Light(50);
    LCD_Open_Light();
}

void display_message(const char *title, const char *detail, const char *action)
{
    LCD_Fill(0, 76, LCD_W, 246, BLACK);
    line(82, title, AQUA);
    line(132, detail, WHITE);
    line(164, action, WHITE);
}

void display_progress(unsigned percent)
{
    if (percent > 100U) percent = 100U;
    char label[] = "  0%";
    if (percent == 100U) label[0] = '1';
    if (percent >= 10U) label[1] = '0' + percent / 10U % 10U;
    label[2] = '0' + percent % 10U;
    line(200, label, WHITE);
    if (!percent) LCD_Fill(20, 234, 220, 242, GRAY);
    else LCD_Fill(20, 234, 20 + 2 * percent, 242, AQUA);
}

void display_off(void)
{
    LCD_CS_Set();
    LCD_Close_Light();
    HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_3);
    HAL_TIM_PWM_DeInit(&htim3);
    HAL_GPIO_DeInit(BLK_PORT, BLK_PIN);
    HAL_SPI_DeInit(&hspi1);
}
