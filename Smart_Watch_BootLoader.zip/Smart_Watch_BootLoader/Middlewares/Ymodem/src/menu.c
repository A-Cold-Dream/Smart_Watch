/**
  ******************************************************************************
  * @file    IAP/IAP_Main/Src/menu.c 
  * @author  MCD Application Team

  * @brief   This file provides the software which contains the main menu routine.
  *          The main menu gives the options of:
  *             - downloading a new binary file, 
  *             - uploading internal flash memory,
  *             - executing the binary file already loaded 
  *             - configuring the write protection of the Flash sectors where the 
  *               user loads his binary file.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2017 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/** @addtogroup STM32F4xx_IAP_Main
  * @{
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "common.h"
#include "flash_if.h"
#include "menu.h"
#include "ymodem.h"
#include <stdio.h>

/* The receiver exposes the last file name through this buffer. */
uint8_t aFileName[FILE_NAME_LENGTH];
static uint8_t app_blocked = 0U;

static void SerialDownload(void)
{
  uint32_t size = 0U;
  COM_StatusTypeDef result;

  /* Do not allow this session to start a partially overwritten image. */
  app_blocked = 1U;
  Serial_PutString((uint8_t *)"Select File > Transfer > YMODEM > Send, then app.bin.\r\n");
  Serial_PutString((uint8_t *)"Waiting for YMODEM; press a to cancel.\r\n");

  /* No text logging is allowed on USART1 inside this receive call. */
  result = Ymodem_Receive(&size);
  HAL_FLASH_Lock();
  if (result == COM_OK)
  {
    if ((size >= 8U) && (size <= USER_FLASH_SIZE) &&
        (APP_IsReady(APPLICATION_ADDRESS) != 0U))
    {
      app_blocked = 0U;
      printf("\r\nDownload OK: %s, %lu bytes. Press 3 to run APP.\r\n",
             (char *)aFileName, (unsigned long)size);
    }
    else
    {
      printf("\r\nFile received, but APP vectors are invalid. Check APP link address.\r\n");
    }
  }
  else
  {
    switch (result)
    {
      case COM_ABORT:   printf("\r\nTransfer cancelled.\r\n"); break;
      case COM_TIMEOUT: printf("\r\nTransfer timed out. Retry with 1.\r\n"); break;
      case COM_LIMIT:   printf("\r\nFile is larger than the APP partition.\r\n"); break;
      case COM_DATA:    printf("\r\nFlash/length error, HAL error=0x%08lX.\r\n",
                              (unsigned long)HAL_FLASH_GetError()); break;
      default:         printf("\r\nYMODEM protocol/header error.\r\n"); break;
    }
  }
}

static void ShowMenu(void)
{
  printf("\r\n========== F407VET6 BootLoader ==========\r\n");
  printf("1: Download APP using YMODEM\r\n");
  printf("3: Run APP\r\n");
  printf("?: Show this menu\r\n");
  printf("APP 0x%08lX..0x%08lX (%lu bytes), USART1 115200 8N1\r\n",
         (unsigned long)APPLICATION_ADDRESS, (unsigned long)(APP_LIMIT - 1U),
         (unsigned long)USER_FLASH_SIZE);
}

void Main_Menu(void)
{
  uint8_t key;

  HAL_FLASH_Lock();
  ShowMenu();
  while (1)
  {
    if (HAL_UART_Receive(&UartHandle, &key, 1U, HAL_MAX_DELAY) != HAL_OK)
    {
      __HAL_UART_CLEAR_OREFLAG(&UartHandle);
      continue;
    }
    switch (key)
    {
      case '1':
        SerialDownload();
        ShowMenu();
        break;
      case '3':
        if ((app_blocked == 0U) && (APP_IsReady(APPLICATION_ADDRESS) != 0U))
        {
          Jump_To_APP(APPLICATION_ADDRESS);
        }
        else
        {
          printf("No runnable APP. Download a complete app.bin with 1 first.\r\n");
        }
        break;
      case '?': ShowMenu(); break;
      case '\r':
      case '\n': break;
      default: printf("Use 1 (download), 3 (run), or ? (menu).\r\n"); break;
    }
  }
}
