"""Upload a Smart_Watch.bin over the watch's transparent BLE UART."""
import argparse
import asyncio
from pathlib import Path
import struct
import zlib

APP_BASE = 0x08008000
MAX_SIZE = 480 * 1024 - 16
TARGET_OFFSET = 0x198
BLOCK = 512
HEADER = struct.Struct("<BIH")
ACK = struct.Struct("<4sIBII")
ERRORS = {1: "bad frame CRC or opcode", 2: "incompatible image",
          3: "unexpected offset", 4: "flash error", 5: "image verification failed"}


def begin_payload(image):
    if not TARGET_OFFSET + 8 < len(image) <= MAX_SIZE:
        raise ValueError("Image length is outside the Smart_Watch APP partition")
    stack, reset = struct.unpack_from("<II", image)
    target = image[TARGET_OFFSET:TARGET_OFFSET + 8]
    if (target != struct.pack("<4sI", b"SWA1", APP_BASE)
            or not 0x20000000 < stack <= 0x20020000 or stack % 8
            or not reset & 1 or not APP_BASE + TARGET_OFFSET + 8 <= reset & ~1 < APP_BASE + len(image)):
        raise ValueError("Expected Smart_Watch.bin linked for 0x08008000")
    return struct.pack("<I", zlib.crc32(image)) + image[:8] + target


def make_frame(op, offset, payload):
    body = HEADER.pack(op, offset, len(payload)) + payload
    tag = zlib.crc32(body)
    return b"SWU1" + body + struct.pack("<I", tag), tag


class Replies:
    def __init__(self):
        self.buffer = bytearray()
        self.queue = asyncio.Queue()

    def notify(self, _characteristic, data):
        self.buffer.extend(data)
        while len(self.buffer) >= ACK.size:
            start = self.buffer.find(b"SWA1")
            if start < 0:
                del self.buffer[:-3]
                return
            del self.buffer[:start]
            if len(self.buffer) < ACK.size:
                return
            _, tag, status, offset, crc = ACK.unpack_from(self.buffer)
            if zlib.crc32(self.buffer[4:13]) != crc:
                del self.buffer[0]
                continue
            del self.buffer[:ACK.size]
            self.queue.put_nowait((tag, status, offset))

    async def matching(self, expected):
        while True:
            tag, status, offset = await self.queue.get()
            if tag == expected:
                return status, offset


async def upload(image, write, replies):
    async def exchange(op, offset, payload):
        frame, tag = make_frame(op, offset, payload)
        for _ in range(3):
            await write(frame)
            try:
                status, next_offset = await asyncio.wait_for(
                    replies.matching(tag), timeout=20 if op == 1 else 6)
            except asyncio.TimeoutError:
                continue
            if status == 1:
                continue
            if status:
                raise RuntimeError(f"Bootloader rejected request: {ERRORS.get(status, status)}")
            return next_offset
        raise TimeoutError("No valid bootloader ACK after three attempts")

    offset = await exchange(1, len(image), begin_payload(image))
    if offset > len(image) or (offset != len(image) and offset % 4):
        raise RuntimeError(f"Invalid resume offset {offset}")
    last_percent = -1
    while offset < len(image):
        block = image[offset:offset + BLOCK]
        expected = offset + len(block)
        offset = await exchange(2, offset, block)
        if offset != expected:
            raise RuntimeError(f"Expected next offset {expected}, got {offset}")
        percent = offset * 100 // len(image)
        if percent != last_percent:
            print(f"\r{percent:3d}%", end="", flush=True)
            last_percent = percent
    if await exchange(3, len(image), b"") != len(image):
        raise RuntimeError("Unexpected END acknowledgement")
    print("\nFirmware verified. Short press the watch button to start.")


def select_char(chars, uuid, properties):
    matches = [char for char in chars if properties.intersection(char.properties)
               and (uuid is None or char.uuid.lower() == uuid.lower())]
    if len(matches) != 1:
        raise ValueError("Select the UART characteristics using --write and --notify. "
                         "Run inspect to list UUIDs and properties.")
    return matches[0]


async def run(args):
    from bleak import BleakClient, BleakScanner

    if args.command == "scan":
        for device in await BleakScanner.discover():
            print(device.address, device.name or "")
        return

    if args.command == "send":
        image = args.image.read_bytes()
        begin_payload(image)
    async with BleakClient(args.address) as client:
        chars = [c for service in client.services for c in service.characteristics]
        if args.command == "inspect":
            for c in chars:
                print(c.service_uuid, c.uuid, ", ".join(c.properties))
            return
        writer = select_char(chars, args.write, {"write", "write-without-response"})
        reader = select_char(chars, args.notify, {"notify", "indicate"})
        replies = Replies()
        await client.start_notify(reader, replies.notify)
        response = "write" in writer.properties

        async def write(frame):
            # 20 bytes also works with the default ATT MTU of 23.
            for i in range(0, len(frame), 20):
                await client.write_gatt_char(writer, frame[i:i + 20], response=response)
                if not response:
                    await asyncio.sleep(0.012)

        await upload(image, write, replies)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("scan")
    sub.add_parser("inspect").add_argument("address")
    send = sub.add_parser("send")
    send.add_argument("address")
    send.add_argument("image", type=Path)
    send.add_argument("--write", help="BLE UART write characteristic UUID")
    send.add_argument("--notify", help="BLE UART notification characteristic UUID")
    args = parser.parse_args()
    try:
        asyncio.run(run(args))
    except ModuleNotFoundError as exc:
        if exc.name != "bleak":
            raise
        parser.exit(1, "Install the BLE dependency: python -m pip install bleak\n")
    except (OSError, RuntimeError, ValueError) as exc:
        parser.exit(1, f"{exc}\n")


if __name__ == "__main__":
    main()
