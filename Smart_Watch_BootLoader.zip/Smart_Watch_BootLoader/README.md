# Smart Watch Bootloader

适用于本工程的 STM32F411CEU6 和 ST7789 屏幕。Boot 使用裸机 HAL，按键为 PA5（低电平按下），PA3 保持板级供电。升级时 PA8 拉高使能蓝牙模块，USART1 通过 PA9/PA10 与模块以 115200、8N1 通信。

## 首次安装

1. 分别构建本工程和相邻的 Smart_Watch 工程。在已配置 STM32Cube 工具链的终端中，两个目录分别执行 `cmake --preset Release` 和 `cmake --build --preset Release`。
2. 用 ST-Link 将本工程的 `build/Release/Smart_Watch_BootLoader.bin` 写到 **0x08000000**。如果手表上还是旧分区的 APP，需重新安装新分区的 APP。
3. 可直接复位并走一次蓝牙升级。也可用 STM32CubeProgrammer 下载 APP 工程的 **Smart_Watch.elf**，按扇区擦除并保留 Bootloader。APP 的 ELF 带有完整性记录。裸 `Smart_Watch.bin` 是蓝牙传输负载，仅把它用调试器写在 0x08008000 不会生成就绪记录。

## 上电和按键

Boot 检查就绪记录、固件长度、目标标识、初始栈、Thumb 复位入口和整个镜像的 CRC32。APP 有效时停在按键界面。短按并松开进入手表 APP，持续按住 800 ms 进入蓝牙升级，按键消抖为 20 ms。APP 无效时直接开启蓝牙并显示等待界面。有效 APP 在等待升级但尚未开始擦除时仍可短按启动。

收到有效的 BEGIN 才开始擦除。升级采用单 APP 分区，写入期间断电后复位会回到升级界面，重新发送完整固件即可。仅蓝牙断开、手表仍上电时，重新发送同一镜像可从设备报告的偏移继续。完成后显示 `Update complete`，短按启动。

## 蓝牙升级

电脑需要 BLE 适配器。发送端在 Bootloader 工程目录运行，Python 依赖为 Bleak。蓝牙模块须工作在双向串口透传模式。

```powershell
python -m pip install bleak
python tools/ota_ble.py scan
python tools/ota_ble.py inspect "设备地址"
python tools/ota_ble.py send "设备地址" "../Smart_Watch/build/Release/Smart_Watch.bin"
```

将“设备地址”替换为扫描到的地址。若设备有多个可写或可通知特征，在最后一条命令追加 `--write "串口写入特征UUID" --notify "串口通知特征UUID"`。这两个 UUID 取自实际模块的透传服务。蓝牙应用层的分片边界与 UART 帧边界相互独立。

## Flash 分区

| 用途 | 地址范围（含两端） | 大小 |
| --- | --- | --- |
| Bootloader | 0x08000000–0x08007FFF | 32 KiB，扇区 0–1 |
| APP 镜像 | 0x08008000–0x0807FFEF | 491504 字节，扇区 2–7 |
| 就绪记录 | 0x0807FFF0–0x0807FFFF | 16 字节，与 APP 共用扇区 7 |

APP ELF 的向量表和 VTOR 都在 0x08008000。向量表之后的偏移 0x198 存有目标字样 `SWA1` 和链接基址。就绪记录依次存放魔数 0x31524459、长度、CRC32、长度按位取反。OTA 先擦除含记录的扇区，再擦除其余所需 APP 扇区，逐块写入并回读。完整镜像校验通过后最后写入魔数。扇区范围见 [STM32F411 参考手册 RM0383 表 4](https://www.st.com/resource/en/reference_manual/rm0383-stm32f411xce-advanced-armbased-32bit-mcus-stmicroelectronics.pdf)。

## 透传协议

所有整数均为小端。请求依次为 4 字节 `SWU1`、操作码 u8、偏移或长度 u32、负载长度 u16、负载、CRC32 u32。CRC 覆盖操作码到负载末尾，算法与 Python `zlib.crc32` 一致。每次只发送一帧，等 Boot 返回 ACK 后再发下一帧。

| 操作 | u32 字段 | 负载 |
| --- | --- | --- |
| BEGIN = 1 | 镜像总长度 | 镜像 CRC32、镜像起始 8 字节、偏移 0x198 起始的 8 字节，共 20 字节 |
| DATA = 2 | 镜像内字节偏移 | 1–512 字节，偏移按 4 字节对齐，末包可不足整字 |
| END = 3 | 镜像总长度 | 空 |

应答为 `SWA1`、请求 CRC32、状态 u8、下一字节偏移 u32、应答 CRC32。应答 CRC 覆盖中间 9 字节。状态 0 表示成功，1–5 依次表示帧错误、镜像不兼容、偏移错误、Flash 错误、最终校验失败。重复发送已经确认的相同数据不会重复编程。CRC32 用于检测损坏，固件来源认证需要另行加入数字签名。
