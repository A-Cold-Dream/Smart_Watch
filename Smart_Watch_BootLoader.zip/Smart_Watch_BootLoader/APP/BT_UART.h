#ifndef BT_UART_H
#define BT_UART_H
#include <stdbool.h>

void bt_update_start(bool app_ready);
void bt_update_poll(void);
bool bt_app_ready(void);

#endif
