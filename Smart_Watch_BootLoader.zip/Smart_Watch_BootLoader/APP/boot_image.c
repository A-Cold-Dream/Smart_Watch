#include "boot_image.h"
#include "main.h"
#include <string.h>

#define READY_MAGIC UINT32_C(0x31524459)
#define CODE_OFFSET (APP_TARGET_OFFSET + 8U)

typedef struct {
    uint32_t ready;
    uint32_t length;
    uint32_t crc;
    uint32_t length_inverse;
} image_record_t;
_Static_assert(sizeof(image_record_t) == 16, "Flash record size");

uint32_t image_crc32(const void *data, uint32_t length)
{
    const uint8_t *p = data;
    uint32_t crc = UINT32_MAX;
    for (uint32_t i = 0; i < length; ++i) {
        crc ^= p[i];
        for (unsigned bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ ((crc & 1U) ? 0xEDB88320U : 0U);
        }
    }
    return ~crc;
}

bool image_vectors_valid(uint32_t length, uint32_t stack, uint32_t reset)
{
    uint32_t entry = reset & ~1U;
    return length > CODE_OFFSET && length <= APP_CAPACITY &&
           stack > SRAM_BASE && stack <= SRAM_BASE + 128U * 1024U && (stack & 7U) == 0 &&
           (reset & 1U) && entry >= APP_BASE + CODE_OFFSET && entry < APP_BASE + length;
}

static bool body_valid(uint32_t length, uint32_t crc)
{
    const uint32_t *vectors = (const uint32_t *)APP_BASE;
    const uint32_t *target = (const uint32_t *)(APP_BASE + APP_TARGET_OFFSET);
    return image_vectors_valid(length, vectors[0], vectors[1]) &&
           target[0] == APP_TARGET_ID && target[1] == APP_BASE &&
           image_crc32(vectors, length) == crc;
}

bool image_valid(void)
{
    const volatile image_record_t *record = (const volatile image_record_t *)APP_RECORD;
    return record->ready == READY_MAGIC && record->length_inverse == ~record->length &&
           body_valid(record->length, record->crc);
}

static bool erase_sectors(uint32_t first, uint32_t count)
{
    FLASH_EraseInitTypeDef erase = {
        .TypeErase = FLASH_TYPEERASE_SECTORS, .Sector = first, .NbSectors = count,
        .VoltageRange = FLASH_VOLTAGE_RANGE_3  /* 3.3 V board */
    };
    uint32_t error_sector;
    return HAL_FLASHEx_Erase(&erase, &error_sector) == HAL_OK;
}

bool image_erase(uint32_t length)
{
    if (length <= CODE_OFFSET || length > APP_CAPACITY || HAL_FLASH_Unlock() != HAL_OK)
        return false;

    /* Drop cached reads of the old image before erase/program/readback. */
    __HAL_FLASH_DATA_CACHE_DISABLE();
    __HAL_FLASH_DATA_CACHE_RESET();
    __HAL_FLASH_INSTRUCTION_CACHE_DISABLE();
    __HAL_FLASH_INSTRUCTION_CACHE_RESET();
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR |
                           FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);

    /* Erase the commit record first. Sector 7 may also hold image payload. */
    uint32_t end = APP_BASE + length;
    uint32_t last = FLASH_SECTOR_2;
    if (end > 0x0800C000U) last = FLASH_SECTOR_3;
    if (end > 0x08010000U) last = FLASH_SECTOR_4;
    if (end > 0x08020000U) last = FLASH_SECTOR_5;
    if (end > 0x08040000U) last = FLASH_SECTOR_6;
    bool ok = erase_sectors(FLASH_SECTOR_7, 1U) &&
              erase_sectors(FLASH_SECTOR_2, last - FLASH_SECTOR_2 + 1U);
    HAL_FLASH_Lock();
    return ok;
}

static bool program_word(uint32_t address, uint32_t word)
{
    return HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, address, word) == HAL_OK &&
           *(const volatile uint32_t *)address == word;
}

bool image_write(uint32_t offset, const uint8_t *data, uint32_t length)
{
    if ((offset & 3U) || offset > APP_CAPACITY || length > APP_CAPACITY - offset ||
        HAL_FLASH_Unlock() != HAL_OK)
        return false;
    bool ok = true;
    for (uint32_t pos = 0; ok && pos < length; pos += 4U) {
        uint32_t word = UINT32_MAX;
        uint32_t remaining = length - pos;
        memcpy(&word, data + pos, remaining < 4U ? remaining : 4U);
        ok = program_word(APP_BASE + offset + pos, word);
    }
    HAL_FLASH_Lock();
    return ok;
}

bool image_commit(uint32_t length, uint32_t crc)
{
    if (!body_valid(length, crc) || HAL_FLASH_Unlock() != HAL_OK) return false;
    bool ok = program_word(APP_RECORD + 4U, length) &&
              program_word(APP_RECORD + 8U, crc) &&
              program_word(APP_RECORD + 12U, ~length) &&
              program_word(APP_RECORD, READY_MAGIC);
    HAL_FLASH_Lock();
    return ok;
}
