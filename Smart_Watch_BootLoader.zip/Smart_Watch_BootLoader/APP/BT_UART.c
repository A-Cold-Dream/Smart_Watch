#include "BT_UART.h"
#include "boot_display.h"
#include "boot_image.h"
#include "usart.h"
#include <string.h>

/* SWU1 | op:u8 | offset:u32 | length:u16 | payload | crc32(op..payload).
 * Each request waits for SWA1 | request_crc:u32 | status:u8 | next:u32 | crc32. */
enum { BEGIN = 1, DATA = 2, END = 3 };
enum { OK, BAD_FRAME, BAD_IMAGE, BAD_OFFSET, FLASH_ERROR, VERIFY_ERROR };
enum { HEADER = 7, BLOCK = 512, RX_SIZE = 2048 };
static uint8_t rx[RX_SIZE], frame[HEADER + BLOCK + 4];
static uint16_t read_pos, filled, wanted;
static unsigned sync_bytes;
static uint32_t last_byte, total, expected_crc, received;
static unsigned shown_percent;
static bool active, ready, committed;
static volatile bool uart_error;

static uint32_t read32(const uint8_t *p)
{
    uint32_t value;
    memcpy(&value, p, 4);
    return value; /* Cortex-M little endian */
}

static void reply(uint32_t tag, uint8_t status)
{
    uint8_t ack[17] = {'S','W','A','1'};
    memcpy(ack + 4, &tag, 4);
    ack[8] = status;
    memcpy(ack + 9, &received, 4);
    uint32_t crc = image_crc32(ack + 4, 9);
    memcpy(ack + 13, &crc, 4);
    HAL_UART_Transmit(&huart1, ack, sizeof(ack), 100);
}

static uint8_t fail_update(uint8_t status)
{
    active = ready = committed = false;
    display_message("Update failed", status == FLASH_ERROR ? "Flash error" : "Verification failed",
                    "Resend over BLE");
    return status;
}

static uint8_t begin(uint32_t size, const uint8_t *body, unsigned count)
{
    if (count != 20 || read32(body + 12) != APP_TARGET_ID || read32(body + 16) != APP_BASE ||
        !image_vectors_valid(size, read32(body + 4), read32(body + 8))) {
        if (!active)
            display_message("Wrong firmware", "Use Smart_Watch.bin",
                            ready ? "Tap to start app" : "No button needed");
        return BAD_IMAGE;
    }
    uint32_t crc = read32(body);
    if (active && size == total && crc == expected_crc) return OK;

    ready = committed = active = false;
    received = 0;
    display_message("Erasing flash", "Keep power on", "");
    if (!image_erase(size)) return fail_update(FLASH_ERROR);
    total = size;
    expected_crc = crc;
    active = true;
    shown_percent = 0;
    display_message("Receiving firmware", "Keep power on", "");
    display_progress(0);
    return OK;
}

static uint8_t data(uint32_t offset, const uint8_t *body, unsigned count)
{
    if (!active || count == 0 || offset > total || count > total - offset ||
        (offset & 3U) || ((count & 3U) && offset + count != total))
        return BAD_OFFSET;
    if (offset < received && count <= received - offset &&
        memcmp((const void *)(APP_BASE + offset), body, count) == 0)
        return OK; /* ACK was lost: the packet is already in flash. */
    if (offset != received) return BAD_OFFSET;
    if (!image_write(offset, body, count)) return fail_update(FLASH_ERROR);
    received += count;
    unsigned percent = (received * 100U) / total;
    if (percent != shown_percent) {
        display_progress(percent);
        shown_percent = percent;
    }
    return OK;
}

static uint8_t dispatch(uint8_t op, uint32_t offset, const uint8_t *body, unsigned count)
{
    switch (op) {
    case BEGIN: return begin(offset, body, count);
    case DATA: return data(offset, body, count);
    case END:
        if (count || offset != total || received != total) return BAD_OFFSET;
        if (committed) return OK;
        if (!active) return BAD_OFFSET;
        display_message("Verifying firmware", "Keep power on", "");
        if (!image_commit(total, expected_crc)) return fail_update(VERIFY_ERROR);
        active = false;
        ready = committed = true;
        display_message("Update complete", "Tap to start app", "");
        return OK;
    default: return BAD_FRAME;
    }
}

static void reset_parser(void)
{
    sync_bytes = filled = 0;
    wanted = HEADER;
}

static void consume(uint8_t byte)
{
    static const uint8_t sync[] = {'S','W','U','1'};
    if (sync_bytes < sizeof(sync)) {
        if (byte == sync[sync_bytes]) ++sync_bytes;
        else sync_bytes = (byte == sync[0]);
        return;
    }
    frame[filled++] = byte;
    if (filled != wanted) return;
    unsigned count = frame[5] | ((unsigned)frame[6] << 8);
    if (filled == HEADER) {
        if (count > BLOCK) reset_parser();
        else wanted = HEADER + count + 4;
        return;
    }
    uint32_t tag = read32(frame + HEADER + count);
    uint8_t status = BAD_FRAME;
    if (image_crc32(frame, HEADER + count) == tag)
        status = dispatch(frame[0], read32(frame + 1), frame + HEADER, count);
    reply(tag, status);
    reset_parser();
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *uart)
{
    if (uart == &huart1) uart_error = true;
}

static void start_rx(void)
{
    read_pos = 0;
    reset_parser();
    __HAL_UART_CLEAR_OREFLAG(&huart1);
    if (HAL_UART_Receive_DMA(&huart1, rx, sizeof(rx)) != HAL_OK) uart_error = true;
}

void bt_update_start(bool app_ready)
{
    ready = app_ready;
    start_rx();
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
    display_message(ready ? "Waiting for update" : "Update required", "Send app over BLE",
                    ready ? "Tap to start app" : "No button needed");
}

bool bt_app_ready(void)
{
    return ready;
}

void bt_update_poll(void)
{
    if (uart_error) {
        uart_error = false;
        HAL_UART_AbortReceive(&huart1);
        start_rx();
        return;
    }
    uint32_t now = HAL_GetTick();
    if (sync_bytes && now - last_byte > 2000U) reset_parser();
    unsigned produced = (RX_SIZE - __HAL_DMA_GET_COUNTER(huart1.hdmarx)) % RX_SIZE;
    while (read_pos != produced) {
        uint8_t byte = rx[read_pos];
        read_pos = (read_pos + 1U) % RX_SIZE;
        last_byte = now;
        consume(byte);
    }
}
