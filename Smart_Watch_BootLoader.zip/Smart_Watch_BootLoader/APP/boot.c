#include "boot.h"
#include "boot_image.h"
#include "boot_display.h"
#include "BT_UART.h"
#include "Key.h"
#include "usart.h"

void Boot_HoldPower(void)
{
    /* PA3 holds board power after the physical button is released. */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET);
    GPIO_InitTypeDef pin = {.Pin = GPIO_PIN_3, .Mode = GPIO_MODE_OUTPUT_PP};
    HAL_GPIO_Init(GPIOA, &pin);
}

static void jump_to_app(void) __attribute__((noreturn));
static void jump_to_app(void)
{
    const uint32_t *vectors = (const uint32_t *)APP_BASE;
    display_message("Starting app", "", "");
    HAL_Delay(250);
    HAL_UART_Abort(&huart1);
    HAL_UART_DeInit(&huart1);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
    display_off();
    /* Keep PA3 asserted across the handoff. A global HAL_DeInit resets GPIOA. */
    if (HAL_RCC_DeInit() != HAL_OK) NVIC_SystemReset();
    __disable_irq();
    SysTick->CTRL = 0;
    SysTick->LOAD = 0;
    SysTick->VAL = 0;
    for (unsigned i = 0; i < sizeof(NVIC->ICER) / sizeof(NVIC->ICER[0]); ++i) {
        NVIC->ICER[i] = UINT32_MAX;
        NVIC->ICPR[i] = UINT32_MAX;
    }
    SCB->ICSR = SCB_ICSR_PENDSTCLR_Msk | SCB_ICSR_PENDSVCLR_Msk;
    SCB->VTOR = APP_BASE;
    __set_CONTROL(0);
    __set_BASEPRI(0);
    __set_FAULTMASK(0);
    __DSB();
    __ISB();
    /* Both operands are already in registers when MSP changes. */
    __asm volatile ("msr msp, %0\n"
                    "cpsie i\n"
                    "bx %1" :: "r"(vectors[0]), "r"(vectors[1]) : "memory");
    __builtin_unreachable();
}

void Boot_Run(void)
{
    display_init();
    display_message("Checking app", "Please wait", "");
    bool valid = image_valid();
    if (valid) {
        display_message("App ready", "Tap to start app", "Hold 0.8s to update");
        bool press_shown = false;
        for (;;) {
            key_event_t key = key_scan(GPIOA, GPIO_PIN_5);
            if (key == KEY_EVT_SHORT) jump_to_app();
            if (key == KEY_EVT_LONG) break;
            if (!press_shown && key_is_pressed()) {
                display_message("Button held", "Release to run app", "Hold to update");
                press_shown = true;
            }
            __WFI();
        }
    }
    bt_update_start(valid);
    for (;;) {
        bt_update_poll();
        if (key_scan(GPIOA, GPIO_PIN_5) == KEY_EVT_SHORT && bt_app_ready()) jump_to_app();
        __WFI();
    }
}
