#ifndef BOOT_IMAGE_H
#define BOOT_IMAGE_H

#include <stdbool.h>
#include <stdint.h>

#define APP_BASE        UINT32_C(0x08008000)
#define APP_RECORD      UINT32_C(0x0807FFF0)
#define APP_CAPACITY    (APP_RECORD - APP_BASE)
#define APP_TARGET_OFFSET 0x198U
#define APP_TARGET_ID   UINT32_C(0x31415753)

uint32_t image_crc32(const void *data, uint32_t length);
bool image_vectors_valid(uint32_t length, uint32_t stack, uint32_t reset);
bool image_valid(void);
bool image_erase(uint32_t length);
bool image_write(uint32_t offset, const uint8_t *data, uint32_t length);
bool image_commit(uint32_t length, uint32_t crc);

#endif
