#ifndef BOOT_H
#define BOOT_H

void Boot_HoldPower(void);
void Boot_Run(void) __attribute__((noreturn));

#endif
